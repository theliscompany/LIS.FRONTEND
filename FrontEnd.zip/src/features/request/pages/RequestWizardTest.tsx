/**
 * Fichier de test pour RequestWizardApiCompatible
 * Utilisez ce fichier pour tester la version API compatible
 */

import RequestWizardApiCompatible from './RequestWizardApiCompatible';

export default function RequestWizardTest() {
  return <RequestWizardApiCompatible />;
}
