
export enum ServiceTypeEnum{
    SEAFREIGHT = 1,
    HAULAGE = 2,
    MISCELLANEOUS = 5,
}